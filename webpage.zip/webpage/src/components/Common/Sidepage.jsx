import React from 'react';
import { Link } from 'react-router-dom';

const Sidepage = ({ section }) => {
    const data = {
        Equity: [
            { name: "Equity Play", link: '/' },
            { name: "Overview", link: '/' },
            { name: "Health Checks", link: '/' },
            { name: "Stakeholders", link: '/stakeholders' },
            { name: "Equity Plans", link: '/' },
            { name: "Securities", link: '/' },
            { name: "Transactions", link: '/' },
            { name: "Valuations", link: '/' },
            { name: "Reports", link: '/' },
            { name: "Simulations", link: '/' },
            { name: "Liquidity", link: '/' },
            { name: "Configuration", link: '/' }
        ],
        Raise:[
            { name: "Raise", link: '/' },
            { name: "Overview", link: '/raiseoverview' },
            { name: "Investor updates", link: '/' },
            { name: "Data rooms", link: '/' },
            { name: "Market insights", link: '/' },
            { name: "Contacts", link: '/' },
        ]
    };

    if (!data[section]) {
        return null; 
    }

    const sectionData = data[section] || [];
    const firstItem = sectionData[0];
    const remainingItems = sectionData.slice(1);

    return (
        <div className="w-60 bg-white min-h-screen text-black border-r-2 border-gray-300">
            <div className="p-3">
                {firstItem && (
                    <div className="text-2xl font-bold">{firstItem.name}</div>
                )}
                <div className="pt-4 pl-1">
                    {remainingItems.map((item, index) => (
                        <Link to={item.link} key={index}>
                            <div className="mb-1">
                                <p className="px-2 mt-5 py-1 font-semibold hover:bg-black hover:text-white transition-colors duration-300 rounded">
                                    {item.name}
                                </p>
                            </div>
                        </Link>
                    ))}
                </div>
            </div>
        </div>
    );
}

export default Sidepage;
