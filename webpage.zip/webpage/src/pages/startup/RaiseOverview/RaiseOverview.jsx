import React, { useState } from 'react';
import { RiArrowDropDownLine, RiLoader2Fill } from 'react-icons/ri';
import { FaRegSnowflake } from 'react-icons/fa6';
import { useNavigate } from 'react-router-dom';
import VerticalLinearStepper from '../../../components/Common/VerticalLinearStepper';
import { Stepper1 } from '../../../components/Common/Stepper1';
import { Stepper4 } from '../../../components/Common/Stepper4';
import { Stepper3 } from '../../../components/Common/Stepper3';
import { Stepper2 } from '../../../components/Common/Stepper2';
import { Stepper5 } from '../../../components/Common/Stepper5';

export const RaiseOverview = () => {
  const [selectedOption, setSelectedOption] = useState('');
  const [showNewRoundModal, setShowNewRoundModal] = useState(false);
  const [showSecondModal, setShowSecondModal] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const [stepContent, setStepContent] = useState('');
  const navigate = useNavigate(); // Hook for navigation

  const handleRadioChange = (e) => {
    const selectedId = e.target.id;
    setSelectedOption(selectedId);
    if (selectedId === 'newround') {
      setShowNewRoundModal(true);
    }
  };

  const handleNext = () => {
    if (activeStep < steps.length - 1) {
      setActiveStep((prev) => prev + 1);
    } else {
      navigate('/angelround'); // Navigate to AngelRound component
    }
  };

  const handleBack = () => {
    if (activeStep > 0) {
      setActiveStep((prev) => prev - 1);
    }
  };

  const handleCloseModal = (e) => {
    e.stopPropagation(); // Prevent click from closing modal
  };

  const steps = [
    { label: 'Stage', description: <Stepper1 /> },
    { label: 'Instrument', description: <Stepper2 /> },
    { label: 'Round Size', description: <Stepper3 /> },
    { label: 'Terms', description: <Stepper4 /> },
    { label: 'Additional Details', description: <Stepper5 /> },
  ];

  return (
    <div className="container-fluid bg-white h-screen w-full">
      <div className="container p-5">
        <div className="m-5">
          <h3 className="text-2xl font-bold">Overview</h3>
          <div className="grid grid-cols-4 gap-4">
            <div className="border p-4">
              <p className="text-gray-500 flex items-center">
                TOTAL RAISED <RiArrowDropDownLine className="text-2xl" />
              </p>
              <div className="text-black font-bold text-3xl">$0</div>
            </div>
            <div className="border p-4">
              <p className="text-gray-500 flex items-center">
                COMMITTED <RiArrowDropDownLine className="text-2xl" />
              </p>
              <div className="text-black font-bold text-3xl">$0</div>
            </div>
            <div className="border p-4">
              <p className="text-gray-500">INVESTORS</p>
              <p className="text-black font-bold text-3xl">0 Direct</p>
            </div>
            <div className="border p-4">
              <p className="text-gray-500">ROUNDS</p>
              <p className="text-black font-bold text-3xl">0</p>
            </div>
          </div>
          <div className="my-5 p-5 text-center font-semibold bg-gray-100">
            <p className="text-gray-500 pt-4 m-4">Create your first financing round</p>
            <div>
              <button className="bg-[#113334] text-white font-semibold py-2 px-4 rounded mr-5" onClick={() => setShowSecondModal(true)}>Add round</button>

              <div className={`fixed inset-0 bg-black bg-opacity-50 z-50 ${showSecondModal ? 'block' : 'hidden'}`} onClick={() => setShowSecondModal(false)}>
                <div className="modal-dialog mx-auto mt-5 max-w-2xl" onClick={handleCloseModal}> {/* Prevent clicks from closing modal */}
                  <div className="modal-content bg-white rounded-lg shadow-lg">
                    <div className="flex justify-between items-center p-4 relative">
                      {/* Close Button */}
                      <button
                        type="button"
                        className="absolute left-4 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-full p-2"
                        onClick={() => setShowSecondModal(false)}
                        aria-label="Close"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="w-5 h-5"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                          strokeWidth="2"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            d="M6 18L18 6M6 6l12 12"
                          />
                        </svg>
                      </button>
                      {/* Continue Button */}
                      <button className="bg-[#113334] text-white font-semibold py-2 px-4 rounded mr-2 ml-auto">Continue</button>
                    </div>
                    <div className="modal-body p-4 text-start">
                      <div className="text-2xl font-semibold mb-4">How would you like to raise?</div>
                      <div className="border p-1 rounded border-blue-500">
                        <div className="flex gap-3 border-2 px-3 py-2 border-gray-800 rounded items-center">
                          <RiLoader2Fill className='bg-gray-200 text-2xl rounded-full p-2' />
                          <label htmlFor="newround" className="flex-1">
                            <div className="font-semibold">New Round</div>
                            <p className="text-gray-500">Raise money quickly with simple terms (SAFE OR Equity). You can always add a Roll Up Vehicle later.</p>
                          </label>
                          <input className="form-check-input border-gray-300" type="radio" name="roundType" id="newround" onChange={handleRadioChange} />
                        </div>
                      </div>
                      <div className="border p-1 mt-2 rounded border-blue-500">
                        <div className="flex gap-3 border-2 px-3 py-2 border-gray-800 rounded items-center">
                          <FaRegSnowflake className='bg-gray-200 text-2xl rounded-full p-2' />
                          <label htmlFor="newround2" className="flex-1">
                            <div className="font-semibold">New Round with a Roll Up Vehicle</div>
                            <p className="text-gray-500">Raise money directly via a Roll Up Vehicle with the same terms. One RUV is included each year with a Growth Plan + subscription or can be purchased as an add-on for $8,000.</p>
                          </label>
                          <input className="form-check-input border-gray-300" type="radio" name="roundType" id="newround2" onChange={handleRadioChange} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {showNewRoundModal && (
                <div
                  className={`fixed inset-0 bg-black bg-opacity-50 z-50 ${showNewRoundModal ? 'block' : 'hidden'}`}
                  onClick={() => setShowNewRoundModal(false)}
                >
                  <div className="modal-dialog mx-auto mt-5 max-w-5xl h-[80vh] flex flex-col" onClick={handleCloseModal}>
                    <div className="modal-content bg-white rounded-lg shadow-lg flex flex-col h-full">
                      <div className="flex justify-between items-center p-4">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            className="text-gray-600 hover:bg-gray-200 p-2 rounded-full"
                            onClick={() => setShowNewRoundModal(false)}
                            aria-label="Close"
                          >
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              className="w-5 h-5"
                              fill="none"
                              viewBox="0 0 24 24"
                              stroke="currentColor"
                              strokeWidth="2"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M6 18L18 6M6 6l12 12"
                              />
                            </svg>
                          </button>
                          <div className="text-xl font-semibold">New Record</div>
                        </div>
                        <div className="flex">
                          <button
                            type="button"
                            className="bg-gray-300 text-gray-800 font-semibold py-2 px-4 rounded mr-3 hover:bg-gray-400"
                            onClick={handleBack}
                            disabled={activeStep === 0}
                          >
                            Back
                          </button>
                          <button
                            type="button"
                            className="bg-[#113334] text-white font-semibold py-2 px-4 rounded hover:bg-blue-600"
                            onClick={handleNext}
                          >
                            {activeStep === steps.length - 1 ? 'Finish' : 'Continue'}
                          </button>
                        </div>
                      </div>
                      <div className="modal-body flex flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200">
                        <div className="w-1/4 p-5 border-r overflow-y-auto">
                          <VerticalLinearStepper
                            steps={steps}
                            onContentChange={(content) => setStepContent(content)}
                            onStepChange={(step) => setActiveStep(step)}
                            activeStep={activeStep}
                          />
                        </div>
                        <div className="w-3/4 p-5 overflow-y-auto">
                          {stepContent}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <button className="bg-transparent border border-green-500 text-green-500 font-semibold px-4 py-2 mb-5 rounded hover:bg-green-500 hover:text-white transition-colors">View FAQs</button>
            </div>
          </div>
          <p className="text-gray-500">AngelList for IN-HAIVE AI SOLUTIONS PRIVATE LIMITED - Pritam Cristpin</p>
        </div>
      </div>
    </div>
  );
};
