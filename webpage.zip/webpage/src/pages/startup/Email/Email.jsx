import React from 'react';
import './Email.css';

const EmailPage = () => {
  return (
    <div className="relative flex min-h-screen flex-col bg-white">
      <div className="absolute top-4 left-4">
        <img 
          className="h-12 w-auto" 
          src="https://your-logo-url.com/logo.svg" 
          alt="AngelList" 
        />
      </div>
      <div className="flex-grow flex items-center justify-center py-5 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8">
          <div className="-ml-8">
            <h2 className="mt-6 ml-3 text-3xl font-medium text-gray-900 border-l-4 border-blue-600 pl-6">
              Check your Email
            </h2>

            <p className="text-sm text-gray-400 mt-4 ml-12">
              We sent an email to <strong>cristpinmarketing@gmail.com</strong> with a magic link and code for easy login or signup.
            </p>

          </div>
          <form className="mt-8 space-y-6 ml-3">
            <div className="relative">
              <input
                id="email-address"
                name="email"
                type="email"
                autoComplete="email"
                required
                className="peer appearance-none rounded-none block w-full px-3 py-5 border border-gray-300 placeholder-transparent text-gray-900 rounded-t-md focus:outline-none focus:border-black-800"
                placeholder=" "
              />
              <label
                htmlFor="email-address"
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 transition-transform duration-300 ease-in-out peer-placeholder-shown:top-1/2 peer-placeholder-shown:text-base peer-placeholder-shown:text-gray-800 peer-focus:-top-4 peer-focus:text-sm peer-focus:text-indigo-600"
              >
                Email Address
              </label>
            </div>
            <div>

            <div className="flex space-x-4">
              <button
                type="submit"
                className="group relative w-35 flex justify-center py-4 px-4 border border-transparent text-xs font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Submit
              </button>

              <button
                type="button"
                className="relative w-1/2 flex justify-center py-4 px-4 border border-gray-300 text-xs font-medium rounded-md text-gray-900 bg-white hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Use Password Instead
              </button>
              </div>

              <div className="mt-8 p-4 border-t border-gray-200">
            <h3 className="text-lg font-bold mb-4">Didn't receive an email?</h3>
            <ul className="list-disc list-inside text-sm text-gray-600 space-y-2">
              <li><a href="#" className="text-blue-600 hover:text-blue-500">Resend this email</a></li>
              <li>Check that the email you entered previously is correct</li>
              <li>Check to see if the email went to your spam folder</li>
              <li>Check back after a few minutes</li>
            </ul>
          </div>

          <div className="mt-6">
            <p className="text-sm text-gray-600">
              If you still have not received an email , please contact us at  <ul href="#">help@angelist.com</ul> 
            </p>
          </div>

          <div className="mt-6">
            <p className="text-sm text-gray-600">
              You can also sign in with <a href="#" className="font-medium text-blue-600 hover:text-blue-500">Google</a> or <a href="#" className="font-medium text-blue-600 hover:text-blue-500">Twitter</a>
            </p>
          </div>

            </div>
          </form>
         
        </div>
      </div>
    </div>
  );
};

export default EmailPage;
