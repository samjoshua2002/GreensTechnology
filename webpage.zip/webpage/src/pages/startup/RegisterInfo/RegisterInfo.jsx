import React from 'react';
import { FiArrowLeft, FiAlertTriangle } from 'react-icons/fi';

const RegisterInfoPage = () => {
  return (
    <div className="relative flex min-h-screen flex-col bg-white">
      <div className="absolute top-4 left-4">
        <img 
          className="h-12 w-auto" 
          src="https://your-logo-url.com/logo.svg" 
          alt="AngelList" 
        />
      </div>
      <div className="flex-grow flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8">
          <FiArrowLeft className="text-gray-600 cursor-pointer mt-3 ml-3 absolute" size={24} />
          <div className="flex items-center space-x-2">
            <h2 className="mt-6 text-center text-3xl font-medium text-gray-900 border-l-4 border-blue-600 pl-4">
              Legal Information
            </h2>
          </div>
          <p className="text-sm text-gray-500 mt-6 ml-4">
            Companies must be registered as corporations in the United States
          </p>

          <form className="mt-8 space-y-6 ml-3">
            <div className="relative">
              <input
                id="legal-name"
                name="legal-name"
                type="text"
                autoComplete="legal-name"
                required
                className="peer appearance-none rounded-none block w-full px-3 py-5 border border-gray-300 placeholder-transparent text-gray-900 rounded-t-md focus:outline-none focus:border-black-800"
                placeholder=" "
              />
              <label
                htmlFor="legal-name"
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 transition-transform duration-300 ease-in-out peer-placeholder-shown:top-1/2 peer-placeholder-shown:text-base peer-placeholder-shown:text-gray-800 peer-focus:-top-4 peer-focus:text-sm peer-focus:text-indigo-600"
              >
                Legal Name
              </label>
            </div>

            <div className="relative">
              <select
                id="company-entity-type"
                name="company-entity-type"
                required
                className="block w-full px-3 py-5 border border-gray-300 text-gray-900 rounded-md focus:outline-none focus:border-black-800"
              >
                <option value="" disabled selected hidden>Company Entity Type</option>
                <option value="corporation">Corporation</option>
                <option value="llc">LLC</option>
                <option value="partnership">Partnership</option>
              </select>
            </div>

            <div className="relative">
              <select
                id="state-of-incorporation"
                name="state-of-incorporation"
                required
                className="block w-full px-3 py-5 border border-gray-300 text-gray-900 rounded-md focus:outline-none focus:border-black-800"
              >
                <option value="" disabled selected hidden>State of Incorporation</option>
                <option value="california">California</option>
                <option value="delaware">Delaware</option>
                <option value="new-york">New York</option>
                {/* Add more states as needed */}
              </select>
            </div>

            <div className="bg-[#FAEBD7] p-4 rounded-md mt-6 relative">
              <div className="flex items-center">
                <FiAlertTriangle className="text-yellow-600 mr-2 absolute -mt-14 -ml-2" size={18} />
                <p className="text-sm text-gray-700 ml-4 mt-1">
                  Unfortunately, AngelList is currently focused solely on serving C Corps and won't be able to move forward in supporting you. If you'd like, you can submit your application and we will notify you if this changes in the future.
                </p>
              </div>
            </div>

            <div>
              <button
                type="submit"
                className="group relative w-35 flex justify-center py-4 px-4 border border-transparent text-xs font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Next
              </button>
            </div>
          </form>

    
        </div>
      </div>
    </div>
  );
};

export default RegisterInfoPage;
