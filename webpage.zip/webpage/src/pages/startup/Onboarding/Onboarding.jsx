import React, { useState } from 'react';
import './Onboarding.css';

const OnboardingPage = () => {
  const [toggle, setToggle] = useState(false);

  const handleToggle = () => {
    setToggle(!toggle);
  };

  return (
    <div className="relative flex min-h-screen flex-col bg-white">
      <div className="absolute top-4 left-4">
        <img 
          className="h-12 w-auto" 
          src="https://your-logo-url.com/logo.svg" 
          alt="AngelList" 
        />
      </div>
      <div className="flex-grow flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8">
          <div className="">
            <h2 className="mt-6 text-3xl font-medium text-gray-900 border-l-4 border-blue-600 pl-6 -ml-8">
              Welcome to AngelList
            </h2>
            <p className="text-sm text-gray-400 mt-4">
              We've created an account for you. Please provide your name below to continue
            </p>
          </div>
          <form className="mt-8 space-y-6 mx-auto">
            <div className="relative">
              <input
                id="email-address"
                name="email"
                type="email"
                autoComplete="email"
                required
                className="peer appearance-none rounded-none block w-full px-3 py-5 border border-gray-300 placeholder-transparent text-gray-900 rounded-t-md focus:outline-none focus:border-black-800"
                placeholder=" "
              />
              <label
                htmlFor="email-address"
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 transition-transform duration-300 ease-in-out peer-placeholder-shown:top-1/2 peer-placeholder-shown:text-base peer-placeholder-shown:text-gray-800 peer-focus:-top-4 peer-focus:text-sm peer-focus:text-indigo-600"
              >
                Full Name
              </label>
            </div>
            <div className="flex items-center mt-4">
              <p className="text-sm text-gray-400 font-bold">
                Add password for future sign-ins (instead of email link and code only)
              </p>
              <div className="ml-2">
                <label className="switch">
                  <input type="checkbox" checked={toggle} onChange={handleToggle} />
                  <span className="slider round"></span>
                </label>
              </div>
            </div>
            <div>
              <button
                type="submit"
                className="group relative w-35 flex justify-center py-4 px-4 border border-transparent text-xs font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Continue
              </button>
            </div>
          </form>
        </div>
      </div>
      <div className="flex justify-center space-x-4 py-4 bg-white border-t border-gray-200">
        <a href="#" className="text-sm text-gray-500 hover:text-gray-700">Terms of Service</a>
        <a href="#" className="text-sm text-gray-500 hover:text-gray-700">Privacy Policy</a>
      </div>
    </div>
  );
};

export default OnboardingPage;
