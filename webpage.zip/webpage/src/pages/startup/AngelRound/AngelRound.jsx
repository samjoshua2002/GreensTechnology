import React, { useState } from 'react';
import { CiLock } from "react-icons/ci";
import { RiArrowDropDownLine } from "react-icons/ri";

export const AngelRound = () => {
  const [hoveredIndex, setHoveredIndex] = useState(null);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  return (
    <div className="bg-white min-h-screen w-full">
      <div className="ml-3 mt-2">
        <nav aria-label="breadcrumb">
          <ol className="flex space-x-2 text-black">
            <li>
              <a href="#" className="text-black no-underline hover:underline">Rounds</a>
            </li>
            <li className="text-gray-500">/ Angel Round</li>
          </ol>
        </nav>
      </div>

      <hr className="w-full" />

      <div className="container ml-14 py-1 w-[90%]">
        <div className="my-5 mt-12">
          <div className="flex justify-between">
            <div className="flex flex-col">
              <h2 className='text-2xl font-semibold'>Angel Round</h2>
              <div className="flex mt-2">
                <span className="bg-blue-100 text-blue-500 rounded  px-1 py-1 text-sm">Raising</span>
                <span className="border text-gray-500 flex items-center ml-2 rounded px-2 py-1 text-sm">
                  <CiLock className="mr-1" /> Private
                </span>
              </div>
            </div>

            <div className="flex items-center">
              <div className="relative mr-2">
                <button
                  className="border rounded p-2 flex items-center justify-between w-32"
                  onClick={toggleDropdown}
                  type="button"
                >
                  Actions <RiArrowDropDownLine />
                </button>
                {isDropdownOpen && (
                  <ul className="absolute right-0 mt-2 w-48 bg-black text-white rounded shadow-lg z-10">
                    <li><a className="block px-4 py-2 hover:bg-gray-700" href="#">Action</a></li>
                    <li><a className="block px-4 py-2 hover:bg-gray-700" href="#">Another action</a></li>
                    <li><a className="block px-4 py-2 hover:bg-gray-700" href="#">Something else here</a></li>
                    <li><a className="block px-4 py-2 hover:bg-gray-700" href="#">Separated link</a></li>
                  </ul>
                )}
              </div>

              <button type="button" className="bg-blue-500 text-white rounded px-4 py-2">Invite</button>
            </div>
          </div>

          <div className="border-2 rounded p-2 mt-6">
            <div className="grid grid-cols-4 border-b">
              <div className="col-span-1 border-r p-2">
                <p className="text-gray-500 text-sm flex items-center mb-1">
                  TOTAL RAISED <RiArrowDropDownLine className='ml-1' />
                </p>
                <div className='text-black font-semibold mb-6 text-xl'>$0</div>
              </div>

              <div className="col-span-1 border-r p-2">
                <p className="text-gray-500 text-sm flex items-center mb-1">
                  COMMITTED <RiArrowDropDownLine className='ml-1' />
                </p>
                <div className='text-black font-semibold mb-6 text-xl'>$0</div>
              </div>

              <div className="col-span-1 border-r p-2">
                <p className="text-gray-500 text-sm mb-1">
                  TARGET SIZE
                </p>
                <div className='text-black font-semibold mb-6 text-xl'>$6,000,000</div>
              </div>

              <div className="col-span-1 p-2">
                <p className="text-gray-500 text-sm mb-1">
                  INVESTORS
                </p>
                <div className='text-black font-semibold mb-6 text-xl'></div>
              </div>
            </div>

            <div className="relative mt-6 mb-4 my-3 h-2 bg-gray-200 rounded-full w-[96%] ml-3">
              <div className="absolute top-0 left-0 h-2 bg-blue-500 rounded-full" style={{ width: '0%' }}></div>
            </div>

            <div className='flex ml-3 mb-3'>
              <p className='flex items-center mr-4'>
                <span className='bg-blue-500 rounded-full w-2.5 h-2.5 mr-2'></span>
                Raised
              </p>

              <p className='flex items-center'>
                <span className='bg-blue-200 rounded-full w-2.5 h-2.5 mr-2'></span>
                Committed
              </p>
            </div>
          </div>

          <p className='mt-2'>
            <a className="text-gray-400 underline" href="#">What is visible to investors?</a>
          </p>

          <div className='mt-8'>
            <nav className="border-b border-gray-300">
              <ul className="flex space-x-4">
                {['Investors', 'Direct Investment', 'Roll Up Vehicle', 'Activity'].map((item, index) => (
                  <li
                    key={index}
                    className={`pb-2 ${hoveredIndex === index ? 'border-b-2 border-blue-500' : ''}`}
                    onMouseEnter={() => setHoveredIndex(index)}
                    onMouseLeave={() => setHoveredIndex(null)}
                  >
                    <a href="#" className={`${hoveredIndex === index ? 'text-black' : 'text-gray-500'} no-underline`}>
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
          </div>

          <div className="container my-5 p-10 text-center font-semibold bg-gray-100">
            <p className="text-gray-500">No investors yet</p>
            <div>
              <button className="bg-black text-white rounded mt-3 px-4 py-2 font-semibold">
                Add offline commitment
              </button>
            </div>
          </div>

          <p>AngelList for IN-HAIVE AI SOLUTIONS PRIVATE LIMITED - Pritam Cristpin</p>
        </div>
      </div>
    </div>
  );
};
