import React from 'react';
import { LuTriangleRight } from "react-icons/lu";
import { GoPlus } from "react-icons/go";
import { IoIosArrowForward } from "react-icons/io";
import { SiCircle } from "react-icons/si";
import { PiNotepadFill } from "react-icons/pi";


const Dashboard = () => {
    return (
        <>
            <div className="container-fluid bg-white min-h-screen w-full">
                <div className="container px-20 mx-auto py-10">
                    <div className="my-4">
                        <h4 className='text-2xl font-semibold'>Welcome Pritam</h4>
                        <div className="container grid grid-cols-2 gap-4 my-4 font-semibold border rounded-lg" style={{ backgroundColor: '#f5f5f5' }}>
                            <div className="col my-auto ms-8 py-3">
                                <LuTriangleRight className='text-xl' />
                                <div className="text-2xl py-1">Start raising</div>
                                <p className='font-medium text-gray-500 mb-4'>Create a round or RUV, invite investors, and close quickly.</p>
                                <button className="bg-[#113334] text-white font-semibold py-2 px-4 rounded mr-2 block mb-4">
                                    Get started
                                </button>
                                <button className="border border-green-600 text-green-600 font-semibold py-2 px-4 rounded">
                                    View FAQs
                                </button>
                            </div>
                            <div className="col bg-white mt-5 px-5">
                                <div className="text-2xl pt-3 text-[#113334]">Pre-Seed Round</div>
                                <span className="inline-block bg-[#e8fa43] text-black text-xs my-4 font-semibold px-2 py-1 rounded">Raising</span>
                                <div className="text-gray-500 mt-2">TOTAL RAISED</div>
                                <div className="text-3xl font-bold my-2 ms-1">$527,000 <span className="text-gray-500">/$2,000,000</span></div>
                                <div className="progress h-2.5 bg-gray-200 my-4">
                                    <div className="progress-bar h-2.5 bg-[#113334] w-1/4"></div>
                                </div>
                                <div className="my-10">
                                    <div className="relative flex items-center">
                                        <span className="py-1 px-2 rounded-full text-white bg-red-500 absolute" style={{ left: '0%' }}>1</span>
                                        <span className="py-1 px-2 rounded-full text-white bg-green-500 absolute" style={{ left: '2%' }}>2</span>
                                        <span className="py-1 px-2 rounded-full text-white bg-yellow-500 absolute" style={{ left: '4%' }}>3</span>
                                        <span className="py-1 px-2 rounded-full text-white bg-teal-500 absolute" style={{ left: '6%' }}>4</span>
                                        <span className="py-1 px-2 rounded-full text-white bg-blue-500 absolute" style={{ left: '8%' }}>5</span>
                                        <span className="py-1 px-2 rounded-full text-white bg-black absolute" style={{ left: '10%' }}>6</span>
                                        <span className="py-1 px-2 rounded-full text-white bg-gray-500 absolute" style={{ left: '12%' }}>7</span>
                                        <div className="absolute font-semibold" style={{ left: '25%' }}>16 investors</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="grid grid-cols-8 gap-4">
                            <div className="col-span-6 border p-3 rounded-lg w-full">
                                <div className="font-semibold text-xl pb-3">Your tasks(2)</div>
                                <div className="accordion" id="accordionExample">
                                    <div className="accordion-item border-0 w-full">
                                        <h2 className="accordion-header">
                                            <button
                                                className="accordion-button p-1 flex items-center gap-3 w-full text-left"
                                                type="button"
                                                data-bs-toggle="collapse"
                                                data-bs-target="#collapseOne"
                                            >
                                                <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
                                                <div className="pl-3 flex-1">
                                                    <div className="mt-1 font-bold">Add Option Holders</div>
                                                    <p className="mt-1 text-gray-500">Sync your human resources platform and add employees.</p>
                                                </div>
                                                <IoIosArrowForward className="text-lg" />
                                            </button>
                                        </h2>
                                        <div id="collapseOne" className="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                                            <div className="accordion-body">
                                                This is the first item's accordion body.
                                            </div>
                                        </div>
                                    </div>

                                    <div className="accordion-item border-0 w-full">
                                        <h2 className="accordion-header">
                                            <button
                                                className="accordion-button p-1 flex items-center gap-3 w-full text-left"
                                                type="button"
                                                data-bs-toggle="collapse"
                                                data-bs-target="#collapseTwo"
                                            >
                                                <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" />
                                                <div className="pl-3 flex-1">
                                                    <div className="mt-1 font-bold">Invite Admin Users</div>
                                                    <p className="mt-1 text-gray-500">Grant admin privileges to your team and other service providers like lawyers and accountants.</p>
                                                </div>
                                                <IoIosArrowForward className="text-lg" />
                                            </button>
                                        </h2>
                                        <div id="collapseTwo" className="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                            <div className="accordion-body">
                                                <strong>This is the second item's accordion body.</strong>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="border p-3 rounded-lg col-span-2">
                                <div className="font-semibold text-xl mb-8">Quick actions</div>
                                <div className='font-medium ml-1'>
                                    <p className="flex items-center gap-2 p-2"><GoPlus className="text-2xl" /> Draft grant</p>
                                    <hr className="text-gray-300 opacity-1 my-2" />
                                    <p className="flex items-center gap-2 p-2"><PiNotepadFill className="text-2xl" /> Make offer</p>
                                    <hr className="text-gray-300 opacity-1 my-2" />
                                    <p className="flex items-center gap-2 p-2"><SiCircle className="text-2xl" /> New round</p>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </>
    )
}

export default Dashboard;
