import React from 'react';
import { FiArrowLeft } from 'react-icons/fi';

const ProductSetupPage = () => {
  return (
    <div className="relative flex min-h-screen flex-col bg-white">
      <div className="absolute top-4 left-4">
        <img 
          className="h-12 w-auto" 
          src="https://your-logo-url.com/logo.svg" 
          alt="AngelList" 
        />
      </div>
      <div className="flex-grow flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-lg w-full space-y-8">
          <div className="flex items-center -ml-12 mb-4">
            <FiArrowLeft className="text-gray-600 cursor-pointer" size={24} />
          </div>
          <div className="-ml-12">
            <h2 className="mt-6 text-center text-3xl font-medium text-gray-900 border-l-4 border-blue-600 pl-5 whitespace-nowrap">
              What products do you want to setup?
            </h2>
          </div>

          {/* Box with Heading and Paragraph */}
          <div className="p-5 -ml-3 rounded-md shadow-md mt-6 border border-gray-300 flex items-center justify-between">
            <div className="flex items-center">
              <img 
                src="https://your-logo-url.com/logo.svg" 
                alt="Logo" 
                className="h-8 w-8 mr-4" 
              />
              <div>
                <h3 className="text-xl font-semibold text-gray-800">Equity</h3>
                <p className="mt-2 text-gray-600">
                  Manage and streamline your cap table, issue equity
                </p>
              </div>
            </div>
            <input type="checkbox" className="h-6 w-6 text-blue-600 border-gray-300 rounded" />
          </div>

          {/* Another Box with Heading and Paragraph */}
          <div className="p-5 -ml-3 rounded-md shadow-md mt-6 border border-gray-300 flex items-center justify-between">
            <div className="flex items-center">
              <img 
                src="https://your-logo-url.com/logo.svg" 
                alt="Logo" 
                className="h-8 w-8 mr-4" 
              />
              <div>
                <h3 className="text-xl font-semibold text-gray-800">Raise</h3>
                <p className="mt-2 text-gray-600">
                  Fundraise using Roll Up Vehicles, SAFEs, and equity rounds
                </p>
              </div>
            </div>
            <input type="checkbox" className="h-6 w-6 text-blue-600 border-gray-300 rounded" />
          </div>

          <form className="mt-8 space-y-6 -ml-3">
            <div>
              <button
                type="submit"
                className="group relative w-40 flex justify-center py-4 px-4 border border-transparent text-xs font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Next
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ProductSetupPage;
