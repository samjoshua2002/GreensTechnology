import React from 'react';
import { FiArrowLeft } from 'react-icons/fi';

const ReviewPage = () => {
  return (
    <div className="relative flex min-h-screen flex-col bg-white">
      <div className="absolute top-4 left-4">
        <img 
          className="h-12 w-auto" 
          src="https://your-logo-url.com/logo.svg" 
          alt="AngelList" 
        />
      </div>
      <div className="flex-grow flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-lg w-full space-y-8">
          <div className="flex items-center -ml-12 mb-4">
            <FiArrowLeft className="text-gray-600 cursor-pointer" size={24} />
          </div>
          <div className="-ml-12">
            <h2 className="mt-6 text-center text-3xl font-medium text-gray-900 border-l-4 border-blue-600 pl-5 whitespace-nowrap">
              Review and agree to terms
            </h2>
          </div>

          {/* Dropdown Component with Custom Box */}
          <div className="mt-6 -ml-12">
            <div className="relative">
              <select 
                id="dropdown" 
                className="block w-full px-3 py-2 bg-white text-gray-900 border-none rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="haive">
                  <div className="flex items-center space-x-2">
                    <div className="h-6 w-6 bg-gray-300 text-center text-white font-bold rounded-md flex items-center justify-center">
                      H
                    </div>
                    <span className="ml-2">HaiVE</span>
                    <br />
                    <span className="text-gray-600">In-HaiVE Solutions</span>
                  </div>
                </option>
                {/* Add more options here if needed */}
              </select>
            </div>
          </div>

          <form className="mt-8 space-y-6 -ml-3">
            <div>
            <h2 className="mt-6  text-3xl font-medium text-gray-900 whitespace-nowrap">
              Terms and acknowledgements
            </h2>
            <p className="mt-4 text-gray-600 text-sm">
              I have read and accept the following agreements: <br />
              <ul className="list-disc list-inside mt-2 space-y-1 text-blue-600">
                <p>Privacy Policy , Terms of Service , Master Subscription <br></br> Agreement , Electronic Disclosure & E-Signature Consent</p>
              </ul>
            </p>
              <button
                type="submit"
                className="group relative w-40 flex justify-center py-4 px-4 border border-transparent text-xs font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Finish Setup
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ReviewPage;
