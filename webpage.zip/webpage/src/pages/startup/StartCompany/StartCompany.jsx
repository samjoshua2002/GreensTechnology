import React from 'react'

function StartCompany() {
  return (
    <div>
      
    </div>
  )
}

export default StartCompany
