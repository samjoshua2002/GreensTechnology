import StartupRoutes from './routes/StartupRoutes'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

function App() {
  return (
    <div>
     <Router>
      <Routes>
        <Route path="/*" element={<StartupRoutes />} />
      </Routes>
    </Router>
    </div>
  );
}

export default App;
