import React from 'react'
import { Route, Routes } from 'react-router-dom';
import LoginPage from '../pages/startup/Login/Login';
import EmailPage from '../pages/startup/Email/Email';
import OnboardingPage from '../pages/startup/Onboarding/Onboarding';
import AboutcompanyPage from '../pages/startup/AboutCompany/AboutCompany';
import LegalInfoPage from '../pages/startup/LegalInfo/LegalInfo';
import RegisterInfoPage from '../pages/startup/RegisterInfo/RegisterInfo';
import ProductSetupPage from '../pages/startup/ProductSetup/ProductSetup';
import ReviewPage from '../pages/startup/Review/Review';
import Dashboard from '../pages/startup/Dashboard/Dashboard';
import { RaiseOverview } from '../pages/startup/RaiseOverview/RaiseOverview';
import { AngelRound } from '../pages/startup/AngelRound/AngelRound';
import { Sidebar } from '../components/Common/Sidebar';
import StartCompany from '../pages/startup/StartCompany/StartCompany';


function StartupRoutes() {
  return (
    <div>
       
          <Routes>
          <Route path="/" element={<LoginPage/>} />
        <Route path="/email" element={<EmailPage/>} />
        <Route path="/onboard" element={<OnboardingPage/>} />
        <Route path="/aboutcompany" element={<AboutcompanyPage/>} />
        <Route path="/legal" element={<LegalInfoPage/>} />
        <Route path="/registerinfo" element={<RegisterInfoPage/>} />
        <Route path="/productsetup" element={<ProductSetupPage/>} />
        <Route path="/review" element={<ReviewPage/>} />
        <Route path="/startcompany" element={<StartCompany/>} />
        </Routes>
      
  
        <div className="flex">
        <Sidebar/>
           <Routes>
          <Route path="/raiseoverview" element={<RaiseOverview />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/angelround" element={<AngelRound/>} />
          </Routes>
          </div>
    </div>
  )
}

export default StartupRoutes
